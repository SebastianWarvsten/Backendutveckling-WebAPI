﻿using System;
namespace AnimalShelter.Repositories
{
    public class AnimalRepository
    {
        public AnimalRepository()
        {
        }
    }
}
