﻿using System;
namespace DogShelter.Entities
{
    public class Dog
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}
